#!/bin/bash
set -e

browserify main.js -o app.js
