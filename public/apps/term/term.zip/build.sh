#!/bin/bash
set -e

BUNDLE_OUT="bundle.js"
BUNDLE_TMP=".$BUNDLE_OUT-$BASHPID"

browserify app.js -o "$BUNDLE_TMP"

function rm_bundle_tmp {
  rm "$BUNDLE_TMP"
}

trap rm_bundle_tmp EXIT

if cmp -s "$BUNDLE_OUT" "$BUNDLE_TMP"; then
  exit
fi

cp "$BUNDLE_TMP" "$BUNDLE_OUT"
